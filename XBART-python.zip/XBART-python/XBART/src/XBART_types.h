#ifndef GUARD_XBART_types_h
#define GUARD_XBART_types_h

#include "tree.h"

#endif
