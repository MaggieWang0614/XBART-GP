#include "tree.h"
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp11)]]
// #include <RcppArmadillo.h>
#include <armadillo>
