#ifndef GUARD_XBCF_types_h
#define GUARD_XBCF_types_h

#include "tree.h"

#endif